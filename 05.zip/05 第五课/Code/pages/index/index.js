var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    page:1,
    limit:2,
    course:[]
  },
  buy:function(){
    wx.showLoading({
      title: '购买中...',
    })

    setTimeout(function(){
      wx.hideLoading({
        success:function(){
          let code = 0;
          if (code == 0) {
            wx.showToast({
              "title": "支付失败",
              icon: "none",
              image: "../images/26-frog.png",
              duration: 3000,
              success: function () {
                wx.navigateTo({
                  url: '../logs/logs',
                })
              }
            })
          } else {
            wx.showModal({
              title: '支付成功',
              content: '是否继续浏览商品',
              confirmColor: "#ff7300",
              success: function (res) {
                console.log(res);
                if (res.confirm == true) {
                  console.log("去吧皮卡丘，剁手去吧！");
                }
              }
            })
          }
        }
      });
    },2000)      
  },

  getCourse:function(){
    wx.request({
      url: app.globalData.url + 'course/index',
      data: {
        page: this.data.page,
        limit: this.data.limit
      },
      method: "post",
      dataType: "json",
      success: (res) => {
        if (res.data.code == 1) {
          let course = this.data.course;
          let limit = this.data.limit;
          let course_data = res.data.data;

          if (course_data.length < limit){
            wx.showToast({
              title: '已经到底了！'
            })
          }

          
          for (var i = 0; i < course_data.length;i++){
            course.push(course_data[i]);
          }
          console.log(course);
          this.setData({
            course:course
          })
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getCourse();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    let course_data = this.data.course;
    course_data = [];
    this.setData({
      course:course_data
    })
    this.getCourse();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    let page = this.data.page;
    this.setData({
      page:++page
    })
    this.getCourse();
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})